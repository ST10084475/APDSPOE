import axios from "axios";
import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import "./App.css"; // Ensure you import your CSS file

function Login({ setIsLoggedIn }) {
  // Accept setIsLoggedIn as a prop
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(
        "http://localhost:3000/api/auth/login",
        { email, password }
      );
      const token = response.data.token;

      // Save the token in localStorage
      localStorage.setItem("token", token);

      // Update logged-in state
      setIsLoggedIn(true); // Notify App that user is logged in

      // Redirect to the home page
      navigate("/home");
    } catch (error) {
      // Display the error message returned from the backend, if available
      alert(error.response?.data?.message || "Invalid credentials");
    }
  };

  return (
    <div>
      <h2>Login</h2>
      <form onSubmit={handleLogin}>
        <label>Email:</label>
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <br />
        <label>Password:</label>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        <br />
        <button type="submit">Login</button>
      </form>
    </div>
  );
}

export default Login;
