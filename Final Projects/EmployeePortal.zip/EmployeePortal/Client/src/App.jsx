import { useState, useEffect } from "react";
import {
  BrowserRouter as Router,
  Route,
  Routes,
  Navigate,
} from "react-router-dom";

import Login from "./Login";
import Home from "./Home";
import Landing from "./Landing";
import About from "./About";
import PaymentsList from "./PaymentsList";
import "./App.css";

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem("token");
    setIsLoggedIn(!!token); // Set to true if token exists
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("token");
    setIsLoggedIn(false);
  };

  return (
    <Router>
      <div className="App">
        <Routes>
          {/* Redirect to home if logged in, otherwise show Landing page */}
          <Route
            path="/"
            element={isLoggedIn ? <Navigate to="/home" /> : <Landing />}
          />
          {/* Route for login */}
          <Route
            path="/login"
            element={<Login setIsLoggedIn={setIsLoggedIn} />}
          />
          {/* Home route */}
          <Route
            path="/home"
            element={
              isLoggedIn ? (
                <Home handleLogout={handleLogout} />
              ) : (
                <Navigate to="/login" />
              )
            }
          />
          {/* PaymentsList route */}
          <Route
            path="/payments-list"
            element={
              isLoggedIn ? (
                <PaymentsList handleLogout={handleLogout} />
              ) : (
                <Navigate to="/login" />
              )
            }
          />
          {/* About route */}
          <Route
            path="/about"
            element={
              isLoggedIn ? (
                <About handleLogout={handleLogout} />
              ) : (
                <Navigate to="/login" />
              )
            }
          />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
