import mongoose from 'mongoose';
import dotenv from 'dotenv';

dotenv.config();

const connectDB = async () => {
    try {
      // Connect to MongoDB using Mongoose
      await mongoose.connect(process.env.ATLAS_URI);
      console.log('1st check of MongoDB connection (conn.mjs)');
    } catch (error) {
      console.error('Error connecting to MongoDB:', error);
      process.exit(1); // Exit if there's an error
    }
};

export default connectDB; // Export the connect function
