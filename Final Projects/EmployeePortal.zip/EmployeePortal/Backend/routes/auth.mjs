import express from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import User from '../models/User.mjs';
import rateLimit from 'express-rate-limit';
import dotenv from 'dotenv';
import cors from 'cors';

dotenv.config();

const app = express();

// Middleware
app.use(cors({ origin: 'http://localhost:5173' })); // Adjust port if needed
app.use(express.json()); // Middleware to parse JSON bodies

// Token generation function
const generateToken = (user) => {
  return jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '1h' });
};

// Middleware to verify the token and ensure the user is an employee
const verifyToken = (req, res, next) => {
  const token = req.headers['authorization']?.split(' ')[1]; // Extract token from Bearer token
  if (!token) {
    console.error('Token is required');
    return res.status(403).json({ message: 'Token is required' });
  }

  jwt.verify(token, process.env.JWT_SECRET, async (err, decoded) => {
    if (err) {
      console.error('Invalid token', err);
      return res.status(403).json({ message: 'Invalid token' });
    }

    try {
      const user = await User.findById(decoded.id); // Fetch user from the database
      if (!user || user.role !== 'employee') {
        console.error('Access denied: Not an employee');
        return res.status(403).json({ message: 'Access denied: Unauthorized' });
      }

      req.user = user; // Attach the user to the request object
      next();
    } catch (dbError) {
      console.error('Error fetching user from database:', dbError);
      res.status(500).json({ message: 'Server error' });
    }
  });
};

// Initialize rate limiter for login route
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // Limit each IP to 5 login attempts per windowMs
  message: {
    message: 'Too many login attempts from this IP, please try again after 15 minutes',
  },
});

const router = express.Router();

// Login Route (with rate limiting)
router.post('/login', loginLimiter, async (req, res) => {
  try {
    const { email, password } = req.body;

    console.log(`Login attempt for email: ${email}`);
    const user = await User.findOne({ email });

    if (!user || user.role !== 'employee') {
      console.error('Invalid credentials or not an employee');
      return res.status(403).json({ message: 'Invalid credentials or unauthorized' });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    console.log(`Password match status: ${isMatch}`);

    if (!isMatch) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    const token = generateToken(user);
    res.json({ token, message: 'Login successful' });
  } catch (error) {
    console.error('Error during login:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

export default router;
export { verifyToken };
