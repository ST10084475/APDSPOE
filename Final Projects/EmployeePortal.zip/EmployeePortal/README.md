# EmployeePortal
For APDS
PLease refer to the "C:\Users\hkado\OneDrive - ADvTECH Ltd\Documents\GitHub\EmployeePortal\ApdsPoeFinal Project Guide & Readme.pdf"