// C:\Users\hkado\PPortal\Client\src\Home.jsx
import React from "react";
import Navbar from "./Navbar";

function Home({ handleLogout }) {
  return (
    <div>
      <Navbar handleLogout={handleLogout} />
      <h1>Welcome to the Home Page</h1>
    </div>
  );
}

export default Home;
