// Hash Password Script
import bcrypt from 'bcryptjs';

// Password to hash
const plainPassword = ""; // Replaced actual password

// Generate hash
bcrypt.hash(plainPassword, 10, (err, hash) => {
  if (err) {
    console.error('Error hashing password:', err);
    return;
  }
  console.log('Hashed Password:', hash);
});