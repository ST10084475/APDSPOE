// C:\Users\hkado\PPortal\Client\src\Navbar.jsx
import React from "react";
import { Link } from "react-router-dom";

function Navbar({ handleLogout }) {
  return (
    <nav style={navbarStyle}>
      <Link to="/home" style={linkStyle}>
        Home
      </Link>
      <Link to="/payments-list" style={linkStyle}>
        Payments List
      </Link>
      <Link to="/about" style={linkStyle}>
        About
      </Link>
      <button onClick={handleLogout} style={buttonStyle}>
        Logout
      </button>
    </nav>
  );
}

const navbarStyle = {
  display: "flex",
  justifyContent: "space-between",
  padding: "10px",
  backgroundColor: "#4CAF50", // Example color
  color: "white",
};

const linkStyle = {
  color: "white",
  textDecoration: "none",
  margin: "0 15px",
};

const buttonStyle = {
  backgroundColor: "red",
  color: "white",
  border: "none",
  padding: "5px 10px",
  cursor: "pointer",
};

export default Navbar;
