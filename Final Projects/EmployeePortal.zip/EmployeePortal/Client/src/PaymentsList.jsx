import React, { useEffect, useState } from "react";
import axios from "axios";
import Navbar from "./Navbar"; // Import the Navbar component

const PaymentsList = ({ handleLogout }) => {
  const [payments, setPayments] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Fetch payments when the component loads
    const fetchPayments = async () => {
      try {
        const token = localStorage.getItem("token"); // Get the JWT token from localStorage
        if (!token) {
          throw new Error("Unauthorized: No token found");
        }

        const response = await axios.get("http://localhost:3000/api/payments", {
          headers: {
            Authorization: `Bearer ${token}`, // Include the token in the Authorization header
          },
        });

        setPayments(response.data); // Update state with fetched payments
      } catch (err) {
        console.error("Error fetching payments:", err.message || err);
        setError(err.message || "An error occurred while fetching payments.");
      }
    };

    fetchPayments();
  }, []);

  return (
    <div>
      <Navbar handleLogout={handleLogout} /> {/* Include Navbar */}
      <h2>Payments List</h2>
      {error && <p style={{ color: "red" }}>{error}</p>}
      {payments.length > 0 ? (
        <table>
          <thead>
            <tr>
              <th>Amount</th>
              <th>Currency</th>
              <th>Provider</th>
              <th>Recipient Account</th>
              <th>SWIFT Code</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            {payments.map((payment) => (
              <tr key={payment._id}>
                <td>{payment.amount}</td>
                <td>{payment.currency}</td>
                <td>{payment.provider}</td>
                <td>{payment.recipientAccount}</td>
                <td>{payment.swiftCode}</td>
                <td>{new Date(payment.createdAt).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        !error && <p>No payments found.</p>
      )}
    </div>
  );
};

export default PaymentsList;
