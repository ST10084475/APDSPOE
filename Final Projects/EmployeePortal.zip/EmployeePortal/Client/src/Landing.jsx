import { Link } from "react-router-dom";

function Landing() {
  return (
    <div>
      <h1>Welcome to Employee Payment Portal</h1>
      <p>Please Login To Access:</p>
      <Link to="/login">
        <button>Login</button>
      </Link>
    </div>
  );
}

export default Landing;
