import express from 'express';
import Payment from '../models/Payment.mjs';
import { verifyToken } from './auth.mjs'; // Middleware to verify JWT

const router = express.Router();

// GET /api/payments - Fetch all payments (only for employees)
router.get('/', verifyToken, async (req, res) => {
  try {
    const { role } = req.user; // Extract role from token

    // Restrict access to employees only
    if (role !== 'employee') {
      console.error(`Access denied for role: ${role}`);
      return res.status(403).json({ message: 'Access denied: Only employees can view payments' });
    }

    // Fetch all payments
    const payments = await Payment.find().populate('userId', 'username email'); // Optional: Populate user details
    res.status(200).json(payments);
  } catch (error) {
    console.error('Error fetching payments:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

export default router;
