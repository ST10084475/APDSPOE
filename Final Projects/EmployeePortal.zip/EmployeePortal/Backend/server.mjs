import http from 'http'; // Add this line for HTTP server
import app from './app.mjs';
import connectDB from './db/conn.mjs'; // Ensure this is a valid connection function

const PORT = process.env.PORT || 3000;

async function startServer() {
  try {
    await connectDB(); // Connect to MongoDB
    console.log('MongoDB is connected (server.mjs)');

    // Use HTTP server
    const server = http.createServer(app);

    server.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error('Error connecting to MongoDB:', error);
  }
}

// Start the server
startServer();
